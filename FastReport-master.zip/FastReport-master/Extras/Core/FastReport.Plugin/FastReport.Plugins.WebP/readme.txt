How to use it:
- execute the following code once at the application start:
new WebPAssemblyInitializer();
- now PictureObject can load WebP format 

Note: In some situations, it may be necessary to use other versions of the NativeAssets package, in this case, the project must be built from the sources yourself.