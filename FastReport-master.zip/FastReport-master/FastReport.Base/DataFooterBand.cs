using System;
using System.Collections;

namespace FastReport
{
    /// <summary>
    /// This class represents a data band footer.
    /// </summary>
    public class DataFooterBand : HeaderFooterBandBase
    {
    }
}