using System;
using System.Collections;
using System.ComponentModel;

namespace FastReport
{
    /// <summary>
    /// This class represents a header of the data band.
    /// </summary>
    public class DataHeaderBand : HeaderFooterBandBase
    {
    }
}