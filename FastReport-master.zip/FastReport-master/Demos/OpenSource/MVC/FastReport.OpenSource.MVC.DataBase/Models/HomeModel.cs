﻿using FastReport.Web;

namespace Demo.MVC.DataBase.Models
{
    public class HomeModel
    {
        public WebReport WebReport { get; set; }
        public string[] ReportsList { get; set; }
    }
}
