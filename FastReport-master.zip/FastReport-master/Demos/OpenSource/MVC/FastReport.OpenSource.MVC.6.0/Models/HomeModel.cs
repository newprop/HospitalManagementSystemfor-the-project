using FastReport.Web;

namespace Demo.MVC.Net6.Models
{
    public class HomeModel
    {
        public WebReport WebReport { get; set; }
        public string[] ReportsList { get; set; }

    }
}
