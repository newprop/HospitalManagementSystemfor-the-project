FastReport Online Designer is web report designer for FastReport.Net for including to own developers web-projects produced with HTML5 and JS technology.

Homepage https://www.fast-report.com/en/product/fast-report-online-designer/

FastReport Online Designer Copyright (C) 2014-2017 Fast Reports Inc.

Read License.rtf for full information of using and distribution

Documentation is available on:
https://www.fast-report.com/en/product/fast-report-online-designer/documentation/
