﻿[run command npm install in folder clientapp to install all needed modules]
1) run backend
2) run setup_client.bat in clientapp folder