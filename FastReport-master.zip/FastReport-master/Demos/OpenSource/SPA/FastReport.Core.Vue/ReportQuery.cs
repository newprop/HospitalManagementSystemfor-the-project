﻿namespace Demo.SPA.Vue;

public class ReportQuery
{
    public string Format { get; set; }

    public string Name { get; set; }

}